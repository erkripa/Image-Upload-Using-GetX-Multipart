var ipconfig = '192.168.38.243';
var path = 'http://$ipconfig:8000';
var url = Uri.parse('http://$ipconfig:8000/api/chatapp/login');
var urlReg = Uri.parse('http://$ipconfig:8000/api/chatapp/registration');
var urlProfilePhotoUpload =
    Uri.parse('http://192.168.38.243:8000/api/chatapp/registration/upload');
var urlUpdateUser = Uri.parse('http://$ipconfig:8000/api/chatapp/user/update');

//http://192.168.38.243:8000/api/chatapp/registration
