// import 'dart:developer';
// import 'dart:io';

// import 'package:image_picker/image_picker.dart';

// class ImagePick {
//   final ImagePicker _picker = ImagePicker();
//   Future<dynamic> pickImage(ImageSource source) async {
//     XFile? pickedFile = await _picker.pickImage(source: source);
//     File _image = File(pickedFile!.path);
//     return _image.path;
//   }
//   // Future<dynamic> pickImage({required ImageSource source}) async {
//   //   XFile? pickedFile = await ImagePicker.pickImage(source: source);
//   //   File _image = File(pickedFile!.path);
//   //   log(_image.path);
//   //   return _image.path;
//   // }
// }
