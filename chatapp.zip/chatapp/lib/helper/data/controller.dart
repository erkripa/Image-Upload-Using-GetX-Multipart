import 'dart:io';

import 'package:chatapp/helper/data/repo.dart';
import 'package:chatapp/helper/data/response_model.dart';
import 'package:get/get.dart';

class AuthController extends GetxController implements GetxService {
  final AuthRepo authRepo;

  AuthController({required this.authRepo});

  bool _isLoading = false;
  bool get isLoading => _isLoading;

//uupload user data while signup
  Future<ResponseModel> uploadUserData(String filename, File file) async {
    _isLoading = true;
    update();
    Response response = await authRepo.uploadUserData(filename, file);

    late ResponseModel responseModel;

    if (response.statusCode == 200) {
      print('uploaded sucuessfully');
      print(response.statusCode);

      responseModel = ResponseModel(true, response.statusText!);
    } else {
      print('not upload');
      print(response.statusText);
      responseModel = ResponseModel(false, response.statusText!);
    }
    _isLoading = false;
    update();
    return responseModel;
  }
}
