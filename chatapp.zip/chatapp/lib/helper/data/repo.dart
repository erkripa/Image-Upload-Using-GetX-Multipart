import 'dart:io';

import 'package:chatapp/helper/constant.dart';
import 'package:chatapp/helper/data/api.dart';
import 'package:get/get.dart';

class AuthRepo {
  final ApiClient apiClient;

  AuthRepo({
    required this.apiClient,
  });

  //
  Future<Response> uploadUserData(String filename, File file) async {
    final form = FormData({
      "image": MultipartFile(file, filename: '$filename.jpg'),
      "filename": ""
    });
    return await apiClient.postImageData(AppConstant.IMAGE_UPLOAD_URI, form);
  }
}
