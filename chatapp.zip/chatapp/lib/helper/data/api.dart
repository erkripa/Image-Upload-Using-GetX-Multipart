import 'package:get/get.dart';

class ApiClient extends GetConnect implements GetxService {
  late String token;
  final String appBaseUrl;
  late Map<String, String> _mainHeaders;

//constuctor with body initialization
  ApiClient({required this.appBaseUrl}) {
    baseUrl = appBaseUrl;
    token = "";
    timeout = const Duration(seconds: 55);
    _mainHeaders = {
      'Content-type': 'application/json; charset=utf-8',
      'Authorization': 'Bearer $token',
    };
  }

//post request
  Future<Response> postImageData(String uri, dynamic body) async {
    // print('inside postdata method ' + body.toString());
    try {
      Response response = await post(
        uri,
        body,
      );
      print(response.toString());
      return response;
    } catch (e) {
      return Response(statusCode: 1, statusText: e.toString());
    }
  }
}
