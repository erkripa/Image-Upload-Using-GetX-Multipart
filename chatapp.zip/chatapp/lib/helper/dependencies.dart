import 'package:chatapp/helper/constant.dart';
import 'package:chatapp/helper/data/api.dart';
import 'package:chatapp/helper/data/controller.dart';
import 'package:chatapp/helper/data/repo.dart';
import 'package:get/get.dart';

Future<void> init() async {
  Get.lazyPut(() => ApiClient(appBaseUrl: AppConstant.APP_BASE_URL));

  //repo
  Get.lazyPut(() => AuthRepo(apiClient: Get.find()));
  //controller
  Get.lazyPut(() => AuthController(authRepo: Get.find()));

}
