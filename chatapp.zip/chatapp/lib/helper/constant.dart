class AppConstant {
  static const APP_BASE_URL = '';//Put your base url inside double quotes //http://google.com

  static const IMAGE_UPLOAD_URI ="" ; //Put your endspoint inside double quotes like /upload
  
}
